FINANCIERA CASTILLO
Proyecto web estático listo para Vercel.
Archivos principales:
- index.html
- vercel.json

Los datos de esta versión se guardan localmente en el navegador mediante localStorage.
Semana operativa: jueves a martes; el corte se realiza el martes.
